using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Player : MonoBehaviour
{
    //CHARACTER WILL BE NAMED 'AFTOS'
    //GREEK FOR 'THYSELF'
    //Variables
    //GOOD LUCK!!

    private float moveSpeed;
    public float runSpeed;
    public float walkSpeed;
    public float rotSpeed;

    public int score = 0;
    public int numHits = 0;
    public float timeElapsed = 0f;

    public float jumpHeight;
    const float Gravity = -9.81f;

    private bool isGrounded;
    private bool justJumped;

    private Vector3 velocity;
    private CharacterController controller;
    private Animator animator;
    private CameraController cam;

    /* CONTROLS
     * WSAD for movement
     * ARROW KEYS for camera control
     * SPACE for jump
     * LEFT SHIFT for sprint
     * for roll
     */

    /* OTHER IDEAS
     * Stamina Meter
     * Health Bar
     * Attack?
     */

    // Start is called before the first frame update
    void Start()
    {
        justJumped = true;
        animator = GetComponentInChildren<Animator>();
        controller = GetComponent<CharacterController>();
        cam = GetComponentInChildren<CameraController>();
    }

    // Update is called once per frame
    void Update()
    {
        timeElapsed += Time.deltaTime;

        Movement();

        if (Input.GetButtonDown("Jump") && isGrounded)
        {
            StartCoroutine(Jump());
        }

        velocity.y += Gravity * Time.deltaTime;
        controller.Move(velocity * Time.deltaTime);
    }

    private void Movement()
    {

        isGrounded = controller.isGrounded;

        if(isGrounded)
        {
            justJumped = false;
        }

        if(isGrounded && velocity.y <= 0f)
        {
            velocity.y = 0f;
        }

        Vector3 move = new Vector3(Input.GetAxis("Horizontal"), 0, Input.GetAxis("Vertical"));


        if (move.x > 0)
        { 
            cam.TurnWithPlayer(true, false);
         }
        else if(move.x< 0)
        {
            cam.TurnWithPlayer(false, true);
        }
        else
        {
            cam.TurnWithPlayer(false, false);
        }

        if (Input.GetKey(KeyCode.LeftArrow))
        {
            cam.getCamera().transform.RotateAround(transform.position, Vector3.up, rotSpeed * Time.deltaTime);
        }
        else if(Input.GetKey(KeyCode.RightArrow))
        {
            cam.getCamera().transform.RotateAround(transform.position, Vector3.up, -rotSpeed * Time.deltaTime);
        }
        if (Input.GetKey(KeyCode.UpArrow))
        {
            //figure out a way to restrict angles
        }
        else if (Input.GetKey(KeyCode.DownArrow))
        {

        }
        if(Input.GetKeyDown(KeyCode.F))
        {
            cam.ResetCamera();
        }

        velocity.y += Gravity * Time.deltaTime;
        controller.Move(velocity * Time.deltaTime);

        if (move != Vector3.zero && !Input.GetKey(KeyCode.LeftShift))
        {
            if (move.z > 0f) //MAKE THESE RELATIVE SOMEHOW!!
            {
                Walk(); //Implement walk forward and walk back
            }
            else
            {
                WalkBackwards();
            }
        }
        else if(move != Vector3.zero && move.z > 0f && Input.GetKey(KeyCode.LeftShift))
        {
            Run(); //Make run only possible when forward velocity > 0
        }
        else
        {
            Idle();
        }
        move = transform.TransformDirection(move); //changes direction

        //if (isGrounded)
        //{
            controller.Move(move.normalized * Time.deltaTime * moveSpeed);
        //}
    }

    private void WalkBackwards()
    {
        moveSpeed = walkSpeed;
        animator.SetFloat("Walk", 0f, .1f, Time.deltaTime);
    }

    private void Walk()
    {
        /*
         * ALWAYS REMEMBER
         * 
         * The first param of SetFloat
         * is in the parameter field of the
         * Animator in Unity animator view
         * 
         */

        moveSpeed = walkSpeed;
        animator.SetFloat("Walk", 0.666f, .1f, Time.deltaTime);
    }

    private void Run()
    {
        moveSpeed = runSpeed;
        animator.SetFloat("Walk", 1f, .1f, Time.deltaTime);
    }

    private void Idle()
    {
        animator.SetFloat("Walk", 0.333f, 0.1f, Time.deltaTime);
    }

    private void StrafeLeft()
    {
        animator.SetFloat("Strafe", 0f, .1f, Time.deltaTime);
    }

    private void StrafeRight()
    {
        animator.SetFloat("Strafe", 1f, .1f, Time.deltaTime);
    }

    private IEnumerator Jump()
    {
        velocity.y += Mathf.Sqrt(jumpHeight * -3f * Gravity);

        animator.SetLayerWeight(animator.GetLayerIndex("Jump"), 1);
        animator.SetTrigger("Jump");

        yield return new WaitForSeconds(1f);

        animator.SetLayerWeight(animator.GetLayerIndex("Jump"), 0);

        justJumped = true;
        //animation behavior


        //JumpUp and JumpDown animations for clamboring


        /* SOMEHOW FIGURE OUT HOW TO JUMP OFF OF
         * CLIFFS/OBSTACLES TO PROPEL SELF FORWARD
         * >PARKOUR!<
         */

        /* CHANGE INPUT TO A/D KEYS ROTATING PLAYER
         * RATHER THAN STRAFE (SET STRAFE TO SHIFT+A:D)
         * 
         * FIX JUMP TO BE INERTIAL (IE, CAN MOVE FORWARD/SIDE/ETC
         * WHILE IN AIR)
         * 
         * MAKE CAMERA ROTATE AROUND PLAYER WITH SET BOUNDS
         * (IMAGINE RUNNING ALONG CLIFFS IN GREECE)
         */
    }

    public void LoadScene()
    {
        SceneManager.LoadScene(score);
    }

    private void OnTriggerStay(Collider other)
    {
        if(other.transform.tag == "MovingPlatform")
        {
            Debug.Log("Should be coasting");
            transform.parent = other.transform;
        }
    }

    private void OnTriggerExit(Collider other)
    {
       if(other.transform.tag == "MovingPlatform")
        {
            transform.parent = null;
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if(other.transform.tag == "Enemy")
        {
            numHits++;
            Debug.Log("Oof! Hit " + numHits + " times!");
        }
    }
}
