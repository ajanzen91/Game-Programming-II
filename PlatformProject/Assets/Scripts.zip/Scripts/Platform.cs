using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Platform : MonoBehaviour
{
    public Transform[] points;
    public float moveSpeed;

    private int destPoint = 0;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if(transform.position.Equals(points[destPoint].position))
        {
            GoToNextPoint();
        }

        transform.position = Vector3.MoveTowards(transform.position, points[destPoint].position, moveSpeed * Time.deltaTime);
    }

    void GoToNextPoint()
    {
        if (points.Length == 0)
        {
            return;
        }
        
        destPoint = (destPoint + 1) % points.Length;
    }
}
