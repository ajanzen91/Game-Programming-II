using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Pickup : MonoBehaviour
{
    private void OnTriggerEnter(Collider collision)
    {
        if (collision.tag == "Player")
        {
            Destroy(this.gameObject);
            collision.gameObject.GetComponent<Player>().score++;
            Debug.Log("Item #" + collision.gameObject.GetComponent<Player>().score + " obtained! Hermes be praised!");
            collision.gameObject.GetComponent<Player>().LoadScene();
        }
    }
}
